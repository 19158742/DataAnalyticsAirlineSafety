package com.pda.PDAMR;

import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Session;

public class CassandraConnection {
	
	private static String KEYSPACE_NAME="test";
	
	public void connectToCassandra() {
	String query = "select * from test.airlinesafe;";	
	Cluster cluster = Cluster.builder().addContactPoint("127.0.0.1").build();
	Session session = cluster.connect(KEYSPACE_NAME);
	ResultSet rs = session.execute(query);
	System.out.println(rs.getExecutionInfo());
	System.out.println(rs.all());
	
	}

}
