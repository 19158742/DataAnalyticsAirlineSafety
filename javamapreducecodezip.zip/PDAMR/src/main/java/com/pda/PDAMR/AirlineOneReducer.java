package com.pda.PDAMR;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.StreamSupport;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reducer;
import org.apache.hadoop.mapred.Reporter;
import org.apache.hadoop.mapred.lib.MultipleOutputFormat;
import org.apache.hadoop.mapred.lib.MultipleOutputs;

import com.sun.tools.javac.util.Context;
import com.sun.tools.javac.util.List;

import org.apache.hadoop.mapreduce.lib.output.LazyOutputFormat;
import org.json.simple.ItemList;

public class AirlineOneReducer extends MapReduceBase implements Reducer<Text, Text, Text, Text> {
	MultipleOutputs mos = null;
	String url = "jdbc:postgresql://airlinedb.cq2itgjroqlm.us-east-1.rds.amazonaws.com:5432/postgres";
	String user = "postgres";
	String password = "postgres";
	public void configure(JobConf job) {
		mos = new MultipleOutputs(job);
	}

	@Override
	public void close() throws IOException {
		mos.close();
	}

	@Override
	public void reduce(Text key, Iterator<Text> values, OutputCollector<Text, Text> output, Reporter reporter)
			throws IOException {
		//System.out.println("I am in reducer ***");
		Long sum = 0L;
		Long comb = 0L;		
		Long totfatac = 0L;
		Long totalfat = 0L;
		Iterator<Text> it = values;
		while (it.hasNext()) {
			Text value = it.next();
			//output.collect(key, value);
			if (value.toString().contains("airline_id") == false) {
				mos.getCollector("airlinelist", reporter).collect(key, value.toString().split(",")[0]); //airline name and row id where the data is present for particular airline			
				saveAirlineListWithIds(key, value.toString().split(",")[0]);
				comb += (Long.parseLong(value.toString().split(",")[3]) + Long.parseLong(value.toString().split(",")[6]));
				totfatac += Long.parseLong(value.toString().split(",")[4]) + Long.parseLong(value.toString().split(",")[7]);
				totalfat += Long.parseLong(value.toString().split(",")[5]) + Long.parseLong(value.toString().split(",")[8]);
				Long kmcount = Long.parseLong(value.toString().split(",")[2]);
				sum+=kmcount;
			}		
		}
		mos.getCollector("fatalacc", reporter).collect(key, totfatac); // total fatal accidents per airline from 1985 to 2014
		saveAirlineTotalFatac(key,totfatac);
		mos.getCollector("fatalities", reporter).collect(key, totalfat); // total fatallities per airline from 1985 to 2014
		saveAirlineTotalFat(key,totalfat);
		mos.getCollector("airlineinc", reporter).collect(key, comb); // total incidents per airline from 1985 to 2014
		saveAirlineIncidents(key,comb);
		mos.getCollector("kmcount", reporter).collect(key, sum); // total km count per airline	
		saveAirlineKmCnt(key,sum);
	}

	private void saveAirlineKmCnt(Text key, Long sum) {
		try {
			Class.forName("org.postgresql.Driver");
			Connection con = DriverManager.getConnection(url, user, password);
			String query = "insert into tblairlinekmcnt(airline_name, total_kmcnt) values ('" + key + "','"+ sum + "')";
			PreparedStatement ps = con.prepareStatement(query);
			ps.executeUpdate();
		} catch (SQLException ex) {
			Logger lgr = Logger.getLogger("Issue in saving data to table tblairlinekmcnt");
			lgr.log(Level.SEVERE, ex.getMessage(), ex);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}		
	}

	private void saveAirlineIncidents(Text key, Long comb) {
		try {
			Class.forName("org.postgresql.Driver");
			Connection con = DriverManager.getConnection(url, user, password);
			String query = "insert into tblairlineincidents(airline_name, total_incidents) values ('" + key + "','"+ comb + "')";
			PreparedStatement ps = con.prepareStatement(query);
			ps.executeUpdate();
		} catch (SQLException ex) {
			Logger lgr = Logger.getLogger("Issue in saving data to table tblairlineincidents");
			lgr.log(Level.SEVERE, ex.getMessage(), ex);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	private void saveAirlineTotalFat(Text key, Long totalfat) {
		try {
			Class.forName("org.postgresql.Driver");
			Connection con = DriverManager.getConnection(url, user, password);
			String query = "insert into tblairlinefatalities(airline_name, total_fatalities) values ('" + key + "','"+ totalfat + "')";
			PreparedStatement ps = con.prepareStatement(query);
			ps.executeUpdate();
		} catch (SQLException ex) {
			Logger lgr = Logger.getLogger("Issue in saving data to table tblairlinefatalities");
			lgr.log(Level.SEVERE, ex.getMessage(), ex);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	private void saveAirlineTotalFatac(Text key, Long totfatac) {
		try {
			Class.forName("org.postgresql.Driver");
			Connection con = DriverManager.getConnection(url, user, password);
			String query = "insert into tblairlinefatalaccidents(airline_name, total_fatac) values ('" + key + "','"+ totfatac + "')";
			PreparedStatement ps = con.prepareStatement(query);
			ps.executeUpdate();
		} catch (SQLException ex) {
			Logger lgr = Logger.getLogger("Issue in saving data to table tblairlinefatalaccidents");
			lgr.log(Level.SEVERE, ex.getMessage(), ex);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}		
	}

	private void saveAirlineListWithIds(Text airlinename, String key) {
		try {
			Class.forName("org.postgresql.Driver");
			Connection con = DriverManager.getConnection(url, user, password);
			String query = "insert into tblairlineinfo(airline_id,airline_name) values ('" + Integer.parseInt(key) + "','"+ airlinename + "')";
			PreparedStatement ps = con.prepareStatement(query);
			ps.executeUpdate();
		} catch (SQLException ex) {
			Logger lgr = Logger.getLogger("Issue in saving data to table tblairlineinfo");
			lgr.log(Level.SEVERE, ex.getMessage(), ex);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}		
	}
}