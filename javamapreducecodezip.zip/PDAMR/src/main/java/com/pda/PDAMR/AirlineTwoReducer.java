package com.pda.PDAMR;

import java.sql.*;
/*import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;*/
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.stream.StreamSupport;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import java.sql.Statement;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
//import org.apache.hadoop.mapreduce.Reducer;

import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reducer;
import org.apache.hadoop.mapred.Reporter;
import org.apache.hadoop.mapred.lib.MultipleOutputFormat;
import org.apache.hadoop.mapred.lib.MultipleOutputs;
import com.sun.tools.javac.util.Context;
//import com.sun.tools.javac.util.List;

import org.apache.hadoop.mapreduce.lib.output.LazyOutputFormat;
import org.json.simple.ItemList;

public class AirlineTwoReducer extends MapReduceBase
		implements Reducer<Text, DoubleWritable, Text, AirlineStdDevTuple> {
	public List<Double> list = new ArrayList<Double>();
	public AirlineStdDevTuple objStdDev = new AirlineStdDevTuple();
	String url = "jdbc:postgresql://airlinedb.cq2itgjroqlm.us-east-1.rds.amazonaws.com:5432/postgres";
	String user = "postgres";
	String password = "postgres";

	@Override
	public void reduce(Text key, Iterator<DoubleWritable> values, OutputCollector<Text, AirlineStdDevTuple> output,
			Reporter reporter) throws IOException {
		System.out.println("in reduce");
		double sum = 0;
		double count = 0;
		list.clear();
		objStdDev.setMedian(0);
		objStdDev.setSd(0);
		Iterator<DoubleWritable> it = values;
		while (it.hasNext()) {
			if (it.hasNext() == true) {
				DoubleWritable value = it.next();
				sum = sum + value.get();
				count = count + 1;
				list.add(value.get());
			}
		}
		Collections.sort(list);
		int length = list.size();
		double median = 0;
		if (length == 2) {
			double medianSum = list.get(0) + list.get(1);
			median = medianSum / 2;
		} else if (length % 2 == 0) {
			double medianSum = list.get((length / 2) - 1) + list.get(length / 2);
			median = medianSum / 2;
		} else {
			median = list.get(length / 2);
		}
		objStdDev.setMedian(median);
		double mean = sum / count;
		double sumOfSquares = 0;
		for (double doubleWritable : list) {
			sumOfSquares += (doubleWritable - mean) * (doubleWritable - mean);
		}
		objStdDev.setSd((double) Math.sqrt(sumOfSquares / (count - 1)));
		output.collect(key, objStdDev);		
		saveToDB(key, objStdDev);
	}

	

	private void saveToDB(Text key, AirlineStdDevTuple objStdDev) {
		try {
			Class.forName("org.postgresql.Driver");
			Connection con = DriverManager.getConnection(url, user, password);
			String query = "insert into tblminstddev(airline_column,data_min,data_stddev) values ('" + key + "','"
					+ objStdDev.getMedian() + "','" + objStdDev.getSd() + "')";
			PreparedStatement ps = con.prepareStatement(query);
			ps.executeUpdate();
		} catch (SQLException ex) {
			Logger lgr = Logger.getLogger("Issue in saving data to table tblminstddev");
			lgr.log(Level.SEVERE, ex.getMessage(), ex);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
}
