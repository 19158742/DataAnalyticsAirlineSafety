package com.pda.PDAMR;

/*import java.io.IOException;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapreduce.Mapper;*/
//import org.apache.hadoop.mapreduce.Mapper;
import java.io.IOException;
import java.util.StringTokenizer;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reporter;

import com.datastax.driver.core.ResultSet;

public class AirlineTwoMapper5 extends MapReduceBase implements Mapper<Object, Text, Text, DoubleWritable> {
	private Text columnNm = new Text();
	private DoubleWritable incidentWritable = new DoubleWritable(0);
	//column - fatalities_85_99

	@Override
	public void map(Object key, Text value, OutputCollector<Text, DoubleWritable> output, Reporter reporter)
			throws IOException {
		//System.out.println("in mapper");		
		String data = value.toString(); 
		String[] field = data.split(",", -1); 
		double inc = 0; 
		if(null != field && field[5].length() > 0 && field[5].toString().contains("fatalities_85_99") == false) { 
			columnNm.set("fatalities_85_99"); 
			inc = Double.parseDouble(field[5]); 
			incidentWritable.set(inc);
			output.collect(columnNm, incidentWritable);
		}		
	}
}
