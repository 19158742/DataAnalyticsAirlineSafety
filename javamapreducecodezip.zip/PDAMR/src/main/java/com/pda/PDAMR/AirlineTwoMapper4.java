package com.pda.PDAMR;

/*import java.io.IOException;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapreduce.Mapper;*/
//import org.apache.hadoop.mapreduce.Mapper;
import java.io.IOException;
import java.util.StringTokenizer;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reporter;

import com.datastax.driver.core.ResultSet;

public class AirlineTwoMapper4 extends MapReduceBase implements Mapper<Object, Text, Text, DoubleWritable> {
	private Text columnNm = new Text();
	private DoubleWritable incidentWritable = new DoubleWritable(0);
	//column - fatal_accidents_00_14
	@Override
	public void map(Object key, Text value, OutputCollector<Text, DoubleWritable> output, Reporter reporter)
			throws IOException {
		//System.out.println("in mapper");		
		String data = value.toString(); 
		String[] field = data.split(",", -1); 
		double inc = 0; 
		if(null != field && field[7].length() > 0 && field[7].toString().contains("fatal_accidents_00_14") == false) { 
			columnNm.set("fatal_accidents_00_14"); 
			inc = Double.parseDouble(field[7]); 
			incidentWritable.set(inc);
			output.collect(columnNm, incidentWritable);
		}		
	}
}
