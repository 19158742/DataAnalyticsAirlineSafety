package com.pda.PDAMR;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.FileInputFormat;
import org.apache.hadoop.mapred.FileOutputFormat;
import org.apache.hadoop.mapred.JobClient;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.TextInputFormat;
import org.apache.hadoop.mapred.TextOutputFormat;
import org.apache.hadoop.mapred.lib.MultipleOutputs;

import com.datastax.driver.core.Cluster;
import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Row;
import com.datastax.driver.core.Session;

import java.io.FileNotFoundException;

public class AirlineRunner {
	static String[] CONTACT_POINTS = { "127.0.0.1" };
	static int PORT = 9042;
	static File myfile1 = new File("/home/hduser/tmp/PDAMR-output2");
	static File myfile2 = new File("/home/hduser/tmp/PDAMR-output1");
	static File myfile3 = new File("/home/hduser/tmp/PDAMR-output3");
	static File myfile4 = new File("/home/hduser/tmp/PDAMR-output4");
	static File myfile5 = new File("/home/hduser/tmp/PDAMR-output5");
	static File myfile6 = new File("/home/hduser/tmp/PDAMR-output6");
	static File myfile7 = new File("/home/hduser/tmp/PDAMR-output7");
	static String url = "jdbc:postgresql://airlinedb.cq2itgjroqlm.us-east-1.rds.amazonaws.com:5432/postgres";
	static String user = ""; //not mentioned for security
	static String password = ""; //not mentioned for security
	public static void main(String[] args) throws IOException {
		AirlineRunner client = new AirlineRunner();
		try {

			client.connect(CONTACT_POINTS, PORT);
			 client.createSchema();
			 client.loadData();
			deleteExistingFiles(client);	
			clearallDB();
			client.querySchema();
			client.findStdDev();
		} finally {
			client.close();
		}
	}
	
	private static void deleteExistingFiles(AirlineRunner client) {
		client.deleteDir(myfile1);
		client.deleteDir(myfile2);
		client.deleteDir(myfile3);
		client.deleteDir(myfile4);
		client.deleteDir(myfile5);
		client.deleteDir(myfile6);
		client.deleteDir(myfile7);		
	}
	
	 

	private static void clearallDB() {
		try {
			Class.forName("org.postgresql.Driver");
			Connection con = DriverManager.getConnection(url, user, password);
			String query1 = "truncate table tblminstddev";
			PreparedStatement ps1 = con.prepareStatement(query1);
			ps1.executeUpdate();
			String query2 = "truncate table tblairlineinfo";
			PreparedStatement ps2 = con.prepareStatement(query2);
			ps2.executeUpdate();
			String query3 = "truncate table tblairlinefatalaccidents";
			PreparedStatement ps3 = con.prepareStatement(query3);
			ps3.executeUpdate();
			String query4 = "truncate table tblairlinekmcnt";
			PreparedStatement ps4 = con.prepareStatement(query4);
			ps4.executeUpdate();
			String query5 = "truncate table tblairlineincidents";
			PreparedStatement ps5 = con.prepareStatement(query5);
			ps5.executeUpdate();
			String query6 = "truncate table tblairlinefatalities";
			PreparedStatement ps6 = con.prepareStatement(query6);
			ps6.executeUpdate();
		} catch (SQLException ex) {
			Logger lgr = Logger.getLogger("Issue in deleting all data of the table tblminstddev");
			lgr.log(Level.SEVERE, ex.getMessage(), ex);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	private void findStdDev() {
		try {
			
			JobConf conf = new JobConf(AirlineRunner.class);
			conf.setJobName("mystddevjob");
			FileInputFormat.setInputPaths(conf, new Path("/home/hduser/Downloads/airline-safety.csv"));
			FileOutputFormat.setOutputPath(conf, new Path("/home/hduser/tmp/PDAMR-output1/"));
			conf.setMapperClass(AirlineTwoMapper.class);
			conf.setReducerClass(AirlineTwoReducer.class);
			conf.setOutputKeyClass(Text.class);
			conf.setOutputValueClass(DoubleWritable.class);
			JobClient.runJob(conf);
			
			JobConf conf2 = new JobConf(AirlineRunner.class);
			conf2.setJobName("mystddevjob2");
			FileInputFormat.setInputPaths(conf2, new Path("/home/hduser/Downloads/airline-safety.csv"));
			FileOutputFormat.setOutputPath(conf2, new Path("/home/hduser/tmp/PDAMR-output3/"));
			conf2.setMapperClass(AirlineTwoMapper2.class);
			conf2.setReducerClass(AirlineTwoReducer.class);
			conf2.setOutputKeyClass(Text.class);
			conf2.setOutputValueClass(DoubleWritable.class);
			JobClient.runJob(conf2);
			
			JobConf conf3 = new JobConf(AirlineRunner.class);
			conf3.setJobName("mystddevjob3");
			FileInputFormat.setInputPaths(conf3, new Path("/home/hduser/Downloads/airline-safety.csv"));
			FileOutputFormat.setOutputPath(conf3, new Path("/home/hduser/tmp/PDAMR-output4/"));
			conf3.setMapperClass(AirlineTwoMapper3.class);
			conf3.setReducerClass(AirlineTwoReducer.class);
			conf3.setOutputKeyClass(Text.class);
			conf3.setOutputValueClass(DoubleWritable.class);
			JobClient.runJob(conf3);
			
			JobConf conf4 = new JobConf(AirlineRunner.class);
			conf4.setJobName("mystddevjob4");
			FileInputFormat.setInputPaths(conf4, new Path("/home/hduser/Downloads/airline-safety.csv"));
			FileOutputFormat.setOutputPath(conf4, new Path("/home/hduser/tmp/PDAMR-output5/"));
			conf4.setMapperClass(AirlineTwoMapper4.class);
			conf4.setReducerClass(AirlineTwoReducer.class);
			conf4.setOutputKeyClass(Text.class);
			conf4.setOutputValueClass(DoubleWritable.class);
			JobClient.runJob(conf4);
			
			JobConf conf5 = new JobConf(AirlineRunner.class);
			conf5.setJobName("mystddevjob5");
			FileInputFormat.setInputPaths(conf5, new Path("/home/hduser/Downloads/airline-safety.csv"));
			FileOutputFormat.setOutputPath(conf5, new Path("/home/hduser/tmp/PDAMR-output6/"));
			conf5.setMapperClass(AirlineTwoMapper5.class);
			conf5.setReducerClass(AirlineTwoReducer.class);
			conf5.setOutputKeyClass(Text.class);
			conf5.setOutputValueClass(DoubleWritable.class);
			JobClient.runJob(conf5);
			
			JobConf conf6= new JobConf(AirlineRunner.class);
			conf6.setJobName("mystddevjob6");
			FileInputFormat.setInputPaths(conf6, new Path("/home/hduser/Downloads/airline-safety.csv"));
			FileOutputFormat.setOutputPath(conf6, new Path("/home/hduser/tmp/PDAMR-output7/"));
			conf6.setMapperClass(AirlineTwoMapper6.class);
			conf6.setReducerClass(AirlineTwoReducer.class);
			conf6.setOutputKeyClass(Text.class);
			conf6.setOutputValueClass(DoubleWritable.class);
			JobClient.runJob(conf6);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void deleteDir(File dir) {
		if (dir.isDirectory()) {
			String[] children = dir.list();
			for (int i = 0; i < children.length; i++) {
				deleteDir(new File(dir, children[i]));
			}
		}
		dir.delete();
	}

	private Cluster cluster;
	private Session session;

	public void connect(String[] contactPoints, int port) {
		cluster = Cluster.builder().addContactPoints(contactPoints).withPort(port).build();
		System.out.printf("Connected to cluster: %s%n", cluster.getMetadata().getClusterName());
		session = cluster.connect();
	}

	public void createSchema() {
		session.execute("CREATE KEYSPACE IF NOT EXISTS test WITH replication "
				+ "= {'class':'SimpleStrategy', 'replication_factor':1};");
		session.execute("CREATE TABLE IF NOT EXISTS test.airlinesafe (" + "airline_id uuid PRIMARY KEY,"
				+ "airline text," + "avail_seat_km_per_week bigint," + "incidents_85_99 int,"
				+ "fatal_accidents_85_99 int," + "fatalities_85_99 int," + "incidents_00_14 int,"
				+ "fatal_accidents_00_14 int," + "fatalities_00_14 int" + ");");
	}

	/** Inserts data into the tables. */
	public void loadData() {
		String csvFile = "/home/hduser/Downloads/airline-safety.csv";
		BufferedReader br = null;
		String line = "";
		String cvsSplitBy = ",";
		try {
			br = new BufferedReader(new FileReader(csvFile));
			while ((line = br.readLine()) != null) {
				String[] mydata = line.split(cvsSplitBy);
				if (!(mydata[0].contains("airline_id"))) {
					session.execute(
							"INSERT INTO test.airlinesafe (airline_id,airline,avail_seat_km_per_week,incidents_85_99,fatal_accidents_85_99,fatalities_85_99,incidents_00_14,fatal_accidents_00_14,fatalities_00_14) "
									+ "VALUES (" + mydata[0] + "," + "'" + mydata[1] + "'," + "" + mydata[2] + "," + ""
									+ mydata[3] + "," + "" + mydata[4] + "," + "" + mydata[5] + "," + "" + mydata[6]
									+ "," + "" + mydata[7] + "," + "" + mydata[8] + "" + ");");
				}
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	public void querySchema() {
		try {
			JobConf conf = new JobConf(AirlineRunner.class);
			conf.setJobName("mypdajob");
			conf.setOutputKeyClass(Text.class);
			conf.setOutputValueClass(Text.class);
			conf.setMapperClass(AirlineOneMapper.class);
			conf.setReducerClass(AirlineOneReducer.class);
			conf.setInputFormat(TextInputFormat.class);
			conf.setOutputFormat(TextOutputFormat.class);
			MultipleOutputs.addNamedOutput(conf, "airlinelist", TextOutputFormat.class, Text.class, Text.class);
			MultipleOutputs.addNamedOutput(conf, "airlineinc", TextOutputFormat.class, Text.class, Text.class);
			MultipleOutputs.addNamedOutput(conf, "kmcount", TextOutputFormat.class, Text.class, Long.class);
			MultipleOutputs.addNamedOutput(conf, "fatalacc", TextOutputFormat.class, Text.class, IntWritable.class);
			MultipleOutputs.addNamedOutput(conf, "fatalities", TextOutputFormat.class, Text.class, IntWritable.class);
			FileInputFormat.setInputPaths(conf, new Path("/home/hduser/Downloads/airline-safety.csv"));
			FileOutputFormat.setOutputPath(conf, new Path("/home/hduser/tmp/PDAMR-output2"));
			JobClient.runJob(conf);

		} catch (Exception e) {
			e.printStackTrace();
		}
		/*
		 * Select data 
		 * ResultSet results =
		 * session.execute("SELECT * FROM test.airlinesafe;");
		 * System.out.printf("%-30s\t%-20s\t%-20s%n%s%s%s%s%s%s", "airline_id",
		 * "airline", "avail_seat_km_per_week", "incidents_85_99",
		 * "fatal_accidents_85_99", "fatalities_85_99", "incidents_00_14",
		 * "fatal_accidents_00_14", "fatalities_00_14");
		 * 
		 * for (Row row : results) {
		 * System.out.printf("%-30s\t%-20s\t%-20s%n%s%s%s%s%s%s",
		 * row.getInt("airline_id"), row.getString("airline"),
		 * row.getLong("avail_seat_km_per_week"), row.getInt("incidents_85_99"),
		 * row.getInt("fatal_accidents_85_99"), row.getInt("fatalities_85_99"),
		 * row.getInt("incidents_00_14"), row.getInt("fatal_accidents_00_14"),
		 * row.getInt("fatalities_00_14")); }
		 */

	}

	/** Closes the session and the cluster. */
	public void close() {
		session.close();
		cluster.close();
	}

}