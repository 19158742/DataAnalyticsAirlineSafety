#!/usr/bin/python
import psycopg2
import numpy as np
import matplotlib.pyplot as plt1
import matplotlib.pyplot as plt2
import matplotlib.pyplot as plt3
import matplotlib.pyplot as plt4
con = None
try:
	con = psycopg2.connect(
		user = "postgres",
		password = "postgres",
		host = "airlinedb.cq2itgjroqlm.us-east-1.rds.amazonaws.com",
		port = "5432",
		database = "postgres"
	    )
	cursor = con.cursor()
	cursor.execute("SELECT * from tblairlinefatalaccidents order by total_fatac desc")
	result = cursor.fetchall()
	cursor.execute("SELECT * from tblairlinefatalities order by total_fatalities desc")
	result2 = cursor.fetchall()
	cursor.execute("SELECT * from tblairlineincidents order by total_incidents desc")
	result3 = cursor.fetchall()
	cursor.execute("SELECT * from tblairlinekmcnt order by total_kmcnt desc")
	result4 = cursor.fetchall()
	airline_name=[]
	airline_name2=[]
	airline_name3=[]
	airline_name4=[]
	total_fatac=[]
	total_fatalities=[]
	total_incidents=[]
	total_kmcnt=[]
	for data in result:
		airline_name.append(data[1])
		total_fatac.append(data[2])
	for data in result2:
		airline_name2.append(data[1])
		total_fatalities.append(data[2])
	for data in result3:
		airline_name3.append(data[1])
		total_incidents.append(data[2])
	for data in result4:
		airline_name4.append(data[1])
		total_kmcnt.append(data[2])
	a = np.array(airline_name)
	b = np.array(total_fatac)
	airline_range1 = a[range(0, 5)] 
	print(airline_range1)
	total1 = b[range(0, 5)] 
	print(total1) 
	colors = 	['y','r','b','m','g'] 	#,'c','y','r','b','y','y','r','b','m','g','c','y','r','b','y','r','b','m','g','c','y','r','b','y','y','r','b','m','g','c','y','r','b','y','y','r','b','m','g','c','y','r','b','y','m','g','c'
	plt1.pie(total1, labels = airline_range1, colors=colors ,shadow = True, explode = (0.05, 0.05, 0.05, 0.05, 0.05), autopct = '%1.1f%%') 
#, 0.05, 0.05, 0.05,0.05, 0.05,0.05, 0.05, 0.05, 0.05, 0.05, 0.05, 0.05, 0.05,0.05,0.05, 0.05, 0.05, 0.05, 0.05, 0.05, 0.05, 0.05,0.05, 0.05,0.05, 0.05, 0.05, 0.05, 0.05, 0.05, 0.05, 0.05,0.05, 0.05, 0.05,0.05, 0.05,0.05, 0.05, 0.05, 0.05, 0.05, 0.05, 0.05, 0.05,0.05, 0.05
	plt1.axis('equal') 
	plt1.show()

	c = np.array(airline_name2)
	d = np.array(total_fatalities)
	airline_range2 = c[range(0, 5)] 
	print(airline_range2)
	total2 = d[range(0, 5)] 
	print(total2) 
	plt2.pie(total2, labels = airline_range2, colors=colors ,shadow = True, explode = (0.05, 0.05, 0.05, 0.05, 0.05), autopct = '%1.1f%%') 
	plt2.axis('equal') 
	plt2.show()

	e = np.array(airline_name3)
	f = np.array(total_incidents)
	airline_range3 = e[range(0, 5)] 
	print(airline_range3)
	total3 = f[range(0, 5)] 
	print(total3) 
	plt3.pie(total3, labels = airline_range3, colors=colors ,shadow = True, explode = (0.05, 0.05, 0.05, 0.05, 0.05), autopct = '%1.1f%%') 
	plt3.axis('equal') 
	plt3.show()

	g = np.array(airline_name4)
	h = np.array(total_kmcnt)
	airline_range4 = g[range(0, 5)] 
	print(airline_range4)
	total4 = h[range(0, 5)] 
	print(total4) 
	plt3.pie(total4, labels = airline_range4, colors=colors ,shadow = True, explode = (0.05, 0.05, 0.05, 0.05, 0.05), autopct = '%1.1f%%') 
	plt4.axis('equal') 
	plt4.show()
except (Exception, psycopg2.Error) as error :
    print ("Error while fetching data from PostgreSQL", error)

cursor.close()
con.close()

