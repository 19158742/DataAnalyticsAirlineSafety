import psycopg2
import numpy
import matplotlib.pyplot as plt
con = None
try:
	con = psycopg2.connect(
		user = "postgres",
		password = "postgres",
		host = "airlinedb.cq2itgjroqlm.us-east-1.rds.amazonaws.com",
		port = "5432",
		database = "postgres"
	    )
	cursor = con.cursor()
	cursor.execute("SELECT * from tblminstddev")
	result = cursor.fetchall()
	med=[]
	std=[]
	for data in result:
		print(data[1])
		med.append(data[2])
		std.append(data[3])

	x = numpy.random.normal(med)
	print(x)
	y = numpy.random.normal(std)
	print(y)

	plt.scatter(x, y)
	plt.xlabel("Median values for the data")
	plt.ylabel("Standard deviation values for the data")
	plt.show()

except (Exception, psycopg2.Error) as error :
    print ("Error while fetching data from PostgreSQL", error)

cursor.close()
con.close()
