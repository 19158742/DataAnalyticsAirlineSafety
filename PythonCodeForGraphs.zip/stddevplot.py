#!/usr/bin/python
import psycopg2
import numpy as np
import matplotlib.pyplot as plt
con = None
try:
	con = psycopg2.connect(
		user = "postgres",
		password = "postgres",
		host = "airlinedb.cq2itgjroqlm.us-east-1.rds.amazonaws.com",
		port = "5432",
		database = "postgres"
	    )
	cursor = con.cursor()
	cursor.execute("SELECT * from tblminstddev")
	result = cursor.fetchall()
	airline_name=[]
	med=[]
	stddev=[]
	for data in result:
		airline_name.append(data[1])
		med.append(data[2])
		stddev.append(data[3])
	 

	plt.plot([],[], color='y', label = 'standard deviation')
	plt.plot([],[], color='r', label = 'median')
	plt.stackplot(airline_name, stddev, med, colors = ['y','r'])
	plt.legend()
	plt.title('Standard deviation and Median in different years')
	plt.xlabel('Airline Name')
	plt.ylabel('Standard deviation and Median')
	plt.show()
except (Exception, psycopg2.Error) as error :
    print ("Error while fetching data from PostgreSQL", error)

cursor.close()
con.close()

